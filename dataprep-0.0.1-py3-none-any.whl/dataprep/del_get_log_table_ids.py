import pandas as pa
import json
import sys
import io
import csv
from utils import get_filters

###############     ############## ----@@@@@--- ######  ]]]]]]---
data=''
for i in sys.stdin:
    data = i
data = json.loads(data)
df=pa.DataFrame(data)
df=df.apply(get_filters,axis=1)
df=df.sort_values(['DA_PK_ID','DA_CHANGE_TIMESTAMP'],ascending=False)
df= df.drop_duplicates(subset=['DA_ID','DA_PK_ID','DA_TABLE_NAME'],keep='first')
df['DA_TABLE_ID']=df['DA_TABLE_ID'].astype('int')

#print("--- ",res.columns)
df= df[['DA_ID','DA_PK_ID','DA_TABLE_NAME','DA_TABLE_ID','PK_NAME',
        'DWH_COLUMN','LOG_DELETE','SQL_FLT','P_KEY','ERR']]
df = df.to_dict(orient='records')
#print("df --> ",df)
#tab=list(df['DA_TABLE_NAME'].unique())

#print("res --> ",res)


#print(df[0])
sys.stdout.write(json.dumps(df))
sys.stdout.flush()