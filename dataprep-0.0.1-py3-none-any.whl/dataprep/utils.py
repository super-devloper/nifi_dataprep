import json
import pandas as pa
import sys
#######    ## --- @@@@@
class DataPrep():
    def __init__(self) -> None:
        pass
    def get_filters(self,val):
        #print("##########################")
        try:
            s=''
            keys_ = []
            f=str(val['DA_FILTERS']).strip()
            
            
            if f!='None':
                json1_data = json.loads(f)    
                for k,v in enumerate(json1_data.items()):
                    
                    keys_.append(v[0])
                    if k==0:
                        s=s+f"to_char({v[0]}) = to_char({v[1]})"
                    else:
                        s=s+' and '+f"to_char({v[0]}) = to_char({v[1]})"
                
                val['SQL_FLT']= s
                val['P_KEY'] =','.join(keys_)
            elif f=='None' and str(val['PK_NAME'])!='None':
                val['SQL_FLT']=s+f"to_char({val['PK_NAME']}) = to_char({val['DA_PK_ID']})"
                val['P_KEY']=val['PK_NAME']
                val['ERR']=0
                return val
        except Exception as e:
            
            val['SQL_FLT']= 'F'
            val['P_KEY'] ='F'
            val['ERR']=1
            return val
    
    def dataprep_nifi(self,stdin,out=[],sort=[],rdup=[]):
        data=''
        for i in sys.stdin:
            data = i
        data = json.loads(data)
        df=pa.DataFrame(data)
        df=df.apply(self.get_filters,axis=1)
        df=df.sort_values(sort,ascending=False)
        df= df.drop_duplicates(subset=rdup,keep='first')
        df['DA_TABLE_ID']=df['DA_TABLE_ID'].astype('int')

        #print("--- ",res.columns)
        df= df[out]
        df = df.to_dict(orient='records')
        return df
